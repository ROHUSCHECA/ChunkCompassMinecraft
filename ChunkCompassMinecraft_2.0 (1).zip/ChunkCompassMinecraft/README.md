# Chunk Compass Minecraft 2.0

App Android para usar el teléfono como visor de chunks de Minecraft.

## Qué hace
- Brújula real del teléfono en grados.
- N / E / S / W y +X / -X / +Z / -Z.
- Cuadrícula visual de 3x3 chunks, con el chunk actual en verde.
- Coordenadas Minecraft X/Y/Z.
- Chunk X/Y/Z y posición local [X,Y,Z].
- GPS para calcular X/Z mientras caminas, después de calibrar un punto de origen.
- Y se mantiene manual porque el GPS no puede conocer la altura Y de Minecraft.
- Botón para abrir la posición GPS en Google Maps.

## Regla GPS -> Minecraft
Minecraft no vincula sus coordenadas a la Tierra. La app usa una calibración:
1. Estás físicamente en un punto.
2. Introduces las coordenadas Minecraft X, Y, Z de ese punto.
3. Pulsas "CALIBRAR AQUÍ".
4. Al caminar, la app mide el desplazamiento GPS.
5. Se usa 1 metro real ≈ 1 bloque Minecraft.
6. Este = +X y Sur = +Z.
7. La orientación del mundo se puede ajustar con "Giro del mundo" si tu mapa no está alineado con los puntos cardinales.

Ejemplo:
Origen Minecraft 0, 64, 0.
Si caminas aproximadamente 10 m hacia el este, X será ~10.
Si caminas aproximadamente 10 m hacia el sur, Z será ~10.

IMPORTANTE:
- Esto NO lee el mundo de Minecraft ni obtiene X/Y/Z directamente desde el juego.
- Para que la app coincida con un mundo real, debes conocer un punto del mundo y calibrarlo.
- El GPS de un celular puede tener varios metros de error, especialmente cerca de edificios.
- La Y de Minecraft debe introducirse manualmente o mediante otra fuente de datos del juego.

## Abrir
Descomprime el ZIP y abre la carpeta en Android Studio. Luego Run en el teléfono.
