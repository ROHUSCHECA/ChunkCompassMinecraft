package com.example.chunkcompass;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private CompassView compass;
    private SensorManager sm;
    private Sensor rotation;
    private LocationManager lm;
    private TextView heading, direction, gps, coords, chunk, local, calibration;
    private EditText x, y, z, scale, worldOffset;
    private double originLat = Double.NaN, originLon = Double.NaN;
    private int originX=0, originY=64, originZ=0;
    private float currentHeading=0f;
    private boolean calibrated=false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        buildUi();
        sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotation=sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        updateMinecraft(originX,originY,originZ);
    }

    private TextView tv(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(6,5,6,5); return t;
    }
    private EditText box(String hint,String value){
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(16); e.setSingleLine(true);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.WHITE); g.setStroke(2,Color.rgb(185,195,190)); g.setCornerRadius(10); e.setBackground(g);
        e.setPadding(9,0,9,0); return e;
    }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(13); return b; }

    private void buildUi(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(14,12,14,18); root.setBackgroundColor(Color.rgb(232,240,242));

        TextView title=tv("CHUNK COMPASS • MINECRAFT",22,Color.rgb(38,53,43)); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(title);
        root.addView(tv("Brújula + chunks 16×16 + coordenadas Minecraft",14,Color.DKGRAY));

        compass=new CompassView(this);
        root.addView(compass,new LinearLayout.LayoutParams(-1,390));

        heading=tv("Rumbo: 0.0°",19,Color.DKGRAY);
        direction=tv("Dirección: N",17,Color.DKGRAY);
        root.addView(heading); root.addView(direction);

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        x=box("X","0"); y=box("Y","64"); z=box("Z","0");
        row.addView(x,new LinearLayout.LayoutParams(0,62,1)); row.addView(y,new LinearLayout.LayoutParams(0,62,1)); row.addView(z,new LinearLayout.LayoutParams(0,62,1));
        root.addView(row);
        Button calc=btn("CALCULAR CHUNK / LOCAL"); calc.setOnClickListener(v->manualCalculate()); root.addView(calc);

        coords=tv("",16,Color.DKGRAY); chunk=tv("",18,Color.rgb(39,83,45)); local=tv("",18,Color.rgb(39,83,45));
        root.addView(coords); root.addView(chunk); root.addView(local);

        root.addView(tv("CALIBRACIÓN GPS → MINECRAFT",18,Color.rgb(38,53,43)));
        root.addView(tv("Primero escribe las coordenadas Minecraft del lugar donde estás y pulsa CALIBRAR AQUÍ.",13,Color.DKGRAY));
        LinearLayout calrow=new LinearLayout(this); calrow.setOrientation(LinearLayout.HORIZONTAL);
        scale=box("bloques/metro","1.0"); worldOffset=box("giro°","0"); 
        calrow.addView(scale,new LinearLayout.LayoutParams(0,62,1)); calrow.addView(worldOffset,new LinearLayout.LayoutParams(0,62,1));
        root.addView(calrow);
        Button cal=btn("CALIBRAR AQUÍ CON GPS"); cal.setOnClickListener(v->calibrateHere()); root.addView(cal);
        calibration=tv("Origen GPS: no calibrado",14,Color.DKGRAY); root.addView(calibration);

        gps=tv("GPS: sin datos",14,Color.DKGRAY); root.addView(gps);
        Button start=btn("ACTIVAR GPS / ACTUALIZAR X Y Z"); start.setOnClickListener(v->requestLocation()); root.addView(start);
        Button maps=btn("ABRIR UBICACIÓN EN GOOGLE MAPS"); maps.setOnClickListener(v->openMaps()); root.addView(maps);

        root.addView(tv("0° N • 90° E • 180° S • 270° W\nCada cuadrado = 1 CHUNK = 16×16 bloques.\nLa Y es altura de Minecraft y se introduce manualmente.",13,Color.rgb(75,88,80)));
        sc.addView(root); setContentView(sc);
    }

    private int val(EditText e,int fallback){
        try{return (int)Math.round(Double.parseDouble(e.getText().toString().trim()));}catch(Exception ex){return fallback;}
    }
    private double dval(EditText e,double fallback){
        try{double v=Double.parseDouble(e.getText().toString().trim()); return Double.isFinite(v)?v:fallback;}catch(Exception ex){return fallback;}
    }

    private void manualCalculate(){
        updateMinecraft(val(x,0),val(y,64),val(z,0));
    }

    private void updateMinecraft(int X,int Y,int Z){
        int cx=Math.floorDiv(X,16), cy=Math.floorDiv(Y,16), cz=Math.floorDiv(Z,16);
        int lx=Math.floorMod(X,16), ly=Math.floorMod(Y,16), lz=Math.floorMod(Z,16);
        coords.setText("Coordenadas: "+X+", "+Y+", "+Z);
        chunk.setText("CHUNK: "+cx+", "+cy+", "+cz);
        local.setText("LOCAL: ["+lx+", "+ly+", "+lz+"]");
        compass.setLocal(lx,ly,lz,cx,cz);
        x.setText(String.valueOf(X)); y.setText(String.valueOf(Y)); z.setText(String.valueOf(Z));
    }

    private void calibrateHere(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ requestLocation(); return; }
        Location l=null;
        try{ l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); }catch(SecurityException ignored){}
        if(l==null){calibration.setText("Origen GPS: esperando ubicación. Activa GPS y vuelve a pulsar.");return;}
        originLat=l.getLatitude(); originLon=l.getLongitude();
        originX=val(x,0); originY=val(y,64); originZ=val(z,0); calibrated=true;
        calibration.setText(String.format(Locale.US,"Origen: %.6f, %.6f → Minecraft %d,%d,%d",originLat,originLon,originX,originY,originZ));
        updateMinecraft(originX,originY,originZ);
    }

    private void requestLocation(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},77); return;
        }
        try{
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,this);
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1000,1,this);
            Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(l!=null)onLocationChanged(l);
        }catch(Exception e){gps.setText("GPS: revisa permisos y ubicación del teléfono.");}
    }

    @Override public void onLocationChanged(Location l){
        gps.setText(String.format(Locale.US,"GPS: %.6f, %.6f • precisión %.1f m • alt %.1f m",l.getLatitude(),l.getLongitude(),l.getAccuracy(),l.getAltitude()));
        if(!calibrated)return;
        double metersPerDegLat=111320.0;
        double metersPerDegLon=111320.0*Math.cos(Math.toRadians(originLat));
        double east=(l.getLongitude()-originLon)*metersPerDegLon;
        double north=(l.getLatitude()-originLat)*metersPerDegLat;
        double rot=Math.toRadians(dval(worldOffset,0));
        double eastR=east*Math.cos(rot)-north*Math.sin(rot);
        double northR=east*Math.sin(rot)+north*Math.cos(rot);
        double blocks=dval(scale,1.0); if(blocks<=0)blocks=1;
        int X=(int)Math.round(originX+eastR*blocks);
        int Z=(int)Math.round(originZ-northR*blocks);
        updateMinecraft(X,originY,Z);
    }

    private void openMaps(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestLocation();return;}
        try{
            Location l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(l==null)l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(l==null){gps.setText("GPS: no hay ubicación todavía.");return;}
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("geo:"+l.getLatitude()+","+l.getLongitude()+"?q="+l.getLatitude()+","+l.getLongitude()));
            startActivity(i);
        }catch(Exception e){startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));}
    }

    private String dir(float d){String[] a={"N","NE","E","SE","S","SW","W","NW"};return a[Math.round(d/45f)%8];}

    @Override public void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
        float[] R=new float[9],o=new float[3]; SensorManager.getRotationMatrixFromVector(R,e.values); SensorManager.getOrientation(R,o);
        float d=(float)Math.toDegrees(o[0]); if(d<0)d+=360;
        currentHeading=d; heading.setText(String.format(Locale.US,"Rumbo: %.1f°",d)); direction.setText("Dirección: "+dir(d)); compass.setHeading(d);
    }
    @Override protected void onResume(){super.onResume();if(rotation!=null)sm.registerListener(this,rotation,SensorManager.SENSOR_DELAY_GAME);}
    @Override protected void onPause(){super.onPause();sm.unregisterListener(this);try{lm.removeUpdates(this);}catch(Exception ignored){}}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public void onProviderEnabled(String s){}
    @Override public void onProviderDisabled(String s){}
    @Override public void onStatusChanged(String s,int a,Bundle b){}

    public class CompassView extends View{
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float h=0; int lx=0,ly=0,lz=0,cx=0,cz=0;
        CompassView(Context c){super(c);p.setTypeface(Typeface.MONOSPACE);}
        void setHeading(float v){h=v;invalidate();}
        void setLocal(int a,int b,int c,int cc,int zz){lx=a;ly=b;lz=c;cx=cc;cz=zz;invalidate();}
        @Override protected void onDraw(Canvas c){
            float w=getWidth(),hh=getHeight(),size=Math.min(w-54,hh-70),left=(w-size)/2,top=12,midX=w/2,midY=top+size/2,q=size/3;
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(53,67,57));c.drawRect(left,top,left+size,top+size,p);
            c.save();c.rotate(-h,midX,midY);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setColor(Color.rgb(172,181,183));
            c.drawLine(left+q,top,left+q,top+size,p);c.drawLine(left+2*q,top,left+2*q,top+size,p);c.drawLine(left,top+q,left+size,top+q,p);c.drawLine(left,top+2*q,left+size,top+2*q,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(57,170,66));c.drawRect(left+q,top+q,left+2*q,top+2*q,p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(25);
            c.drawText("N",midX,top-7,p);c.drawText("S",midX,top+size+29,p);c.drawText("W",left-19,midY+8,p);c.drawText("E",left+size+19,midY+8,p);
            p.setTextSize(15);c.drawText("−Z",midX,top+43,p);c.drawText("+Z",midX,top+size-20,p);c.drawText("−X",left+q/2,midY+6,p);c.drawText("+X",left+size-q/2,midY+6,p);
            c.restore();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(232,52,48));c.drawCircle(midX,midY,5,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(57,170,66));c.drawRect(left+q,top+q,left+2*q,top+2*q,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(45,58,50));p.setTextSize(14);p.setTextAlign(Paint.Align.CENTER);
            c.drawText("Chunk "+cx+", "+cz+" • ["+lx+","+ly+","+lz+"]",midX,top+size+49,p);
        }
    }
}
